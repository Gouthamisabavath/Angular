export class addblockairline{
    Airlineid:string;
    Airlinename:string;
}