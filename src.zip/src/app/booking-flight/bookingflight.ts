export class tickets{
    Username:string;
    Bookingdate:string;
    Flightnumber: number;
    PassengerEmail: string;
    PassengerName:string;
    Numberofseats:number;
    Optformeal: string;
    Seatnumbers:string;
    Pnrnumber: number;
    Useremail: string;
}
