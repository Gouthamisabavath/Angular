export class tickets{
     Pnrnumber:number;
}