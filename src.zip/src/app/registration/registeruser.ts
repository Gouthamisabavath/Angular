export class registerusers
{
     Username:string;
     Email :string;
     Password :string;
     Gender:string;
     Phonenumber :string;
}